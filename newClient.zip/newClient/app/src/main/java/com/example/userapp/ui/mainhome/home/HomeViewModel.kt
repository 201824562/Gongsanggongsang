package com.example.userapp.ui.mainhome.home

import com.example.userapp.base.BaseViewModel

class HomeViewModel : BaseViewModel() {
}