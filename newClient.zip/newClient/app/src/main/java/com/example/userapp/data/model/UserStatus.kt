package com.example.userapp.data.model

enum class UserStatus{
    NOT_USER,
    SUCCESS,
    WAIT_APPROVE
}