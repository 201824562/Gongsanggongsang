package com.example.userapp.ui.mainhome.alarm

import com.example.userapp.base.BaseViewModel

class AlarmViewModel : BaseViewModel() {
}