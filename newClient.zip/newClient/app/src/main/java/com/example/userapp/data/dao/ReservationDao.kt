package com.example.userapp.data.dao

class ReservationDao {
}