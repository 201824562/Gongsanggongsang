package com.example.userapp.data.model

data class ReservationUseEquipment(
    val document_name: String,
    var name: String,
    var start_time: String,
    var end_time: String
)
