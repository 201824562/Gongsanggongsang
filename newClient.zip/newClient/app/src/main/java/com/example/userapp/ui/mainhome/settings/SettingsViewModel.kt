package com.example.userapp.ui.mainhome.settings

import com.example.userapp.base.BaseViewModel

class SettingsViewModel : BaseViewModel() {
}