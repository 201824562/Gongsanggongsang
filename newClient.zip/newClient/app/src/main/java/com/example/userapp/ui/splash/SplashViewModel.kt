package com.example.userapp.ui.splash

import com.example.userapp.base.BaseViewModel

class SplashViewModel : BaseViewModel() {
}