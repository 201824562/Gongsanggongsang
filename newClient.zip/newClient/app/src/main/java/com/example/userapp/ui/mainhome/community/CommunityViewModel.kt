package com.example.userapp.ui.mainhome.community

import com.example.userapp.base.BaseViewModel

class CommunityViewModel : BaseViewModel() {
}