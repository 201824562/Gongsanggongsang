package com.example.userapp.data.model

data class ReservationEquipment(
    val document_name: String,
    var using: String,
    var usage_time: Int
)
