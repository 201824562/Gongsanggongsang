package com.example.userapp.ui.signin

import com.example.userapp.base.BaseViewModel

class SignInViewModel : BaseViewModel() {
}