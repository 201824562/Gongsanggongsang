package com.example.userapp.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/*
@Entity(tableName = "RESERVATION_TABLE")
data class ReservationEntity (
    @ColumnInfo(name = "Type")
    val type : String,

    //더 넣어줘야함 변수들.

    @PrimaryKey(autoGenerate = true)
    val primaryId: Int = 0
)*/
