package com.example.userapp.ui.mainhome

import com.example.userapp.MainActivityViewModel

class MainHomeViewModel : MainActivityViewModel() {
}